﻿import codecs
import re

path = 'C:/Users/raffy/Desktop/MyPatenti Prova/src/main/resources/css/auth.css'
with codecs.open(path, 'r', 'utf-8', errors='ignore') as f:
    content = f.read()

content = re.sub(
    r'\.teoria-module-btn \{[^\}]+\}',
    '.teoria-module-btn {\n    -fx-background-color: #ffffff;\n    -fx-background-radius: 12;\n    -fx-border-radius: 12;\n    -fx-border-color: #e2e8f0;\n    -fx-border-width: 1px;\n    -fx-padding: 20 10 10 10;\n    -fx-cursor: hand;\n    -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 5, 0, 0, 2);\n    -fx-alignment: top-center;\n    -fx-spacing: 15;\n}',
    content
)

content = re.sub(
    r'\.teoria-module-text \{[^\}]+\}',
    '.teoria-module-text {\n    -fx-font-size: 14px;\n    -fx-font-weight: bold;\n    -fx-text-alignment: center;\n    -fx-wrap-text: true;\n    -fx-text-fill: #1e293b;\n}',
    content
)

with codecs.open(path, 'w', 'utf-8') as f:
    f.write(content)
