﻿import codecs
import re

path = 'C:/Users/raffy/Desktop/MyPatenti Prova/src/main/java/controller/VisualizzatoreController.java'
with codecs.open(path, 'r', 'utf-8', errors='ignore') as f:
    content = f.read()

content = content.replace('StackPane thumbWrapper = new StackPane(thumb);\n            final int index = i - 1;', 'StackPane thumbWrapper = new StackPane(thumb);\n            thumbWrapper.getStyleClass().add("thumb-wrapper");\n            final int index = i - 1;')

with codecs.open(path, 'w', 'utf-8') as f:
    f.write(content)
