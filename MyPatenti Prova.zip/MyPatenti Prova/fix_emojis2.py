﻿import codecs
import re

path = 'C:/Users/raffy/Desktop/MyPatenti Prova/src/main/resources/view/Dashboard.fxml'
with codecs.open(path, 'r', 'utf-8', errors='ignore') as f:
    content = f.read()

content = re.sub(r'text="[^"]+ Ciao, Utente"', 'text="\U0001F44B Ciao, Utente"', content)
content = re.sub(r'text="Bentornato, Cristian! [^"]+"', 'text="Bentornato, Cristian! \U0001F697"', content)

with codecs.open(path, 'w', 'utf-8') as f:
    f.write(content)
