﻿import codecs
import re

path = 'C:/Users/raffy/Desktop/MyPatenti Prova/src/main/resources/view/Visualizzatore.fxml'
with codecs.open(path, 'r', 'utf-8', errors='ignore') as f:
    content = f.read()

# I will just replace the buttons completely based on fx:id
content = re.sub(r'<Button fx:id="btnIndietro" text="[^"]+"', '<Button fx:id="btnIndietro" text="&#x2190; Indietro"', content)
content = re.sub(r'<Button fx:id="btnAvanti" text="[^"]+"', '<Button fx:id="btnAvanti" text="Avanti &#x2192;"', content)
content = re.sub(r'<Button text="[^"]+" onAction="#chiudi"', '<Button text="X" onAction="#chiudi"', content)

with codecs.open(path, 'w', 'utf-8') as f:
    f.write(content)
