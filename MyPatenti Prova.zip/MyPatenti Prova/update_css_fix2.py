﻿import codecs
import re

path = 'C:/Users/raffy/Desktop/MyPatenti Prova/src/main/resources/css/auth.css'
with codecs.open(path, 'r', 'utf-8', errors='ignore') as f:
    content = f.read()

content = content.replace('.dark-theme .teoria-module-text {\n    -fx-font-size: 14px;\n    -fx-font-weight: bold;\n    -fx-text-alignment: center;\n    -fx-wrap-text: true;\n    -fx-text-fill: #1e293b;\n}', '.dark-theme .teoria-module-text {\n    -fx-text-fill: #f8fafc;\n}')

with codecs.open(path, 'w', 'utf-8') as f:
    f.write(content)
