﻿import codecs
import re

path = 'C:/Users/raffy/Desktop/MyPatenti Prova/src/main/resources/view/Visualizzatore.fxml'
with codecs.open(path, 'r', 'utf-8', errors='ignore') as f:
    content = f.read()

content = content.replace('style="-fx-font-size: 24px; -fx-background-color: transparent; -fx-cursor: hand; -fx-font-weight: bold; -fx-padding: 0 10 0 0;"', 'styleClass="viewer-close-btn"')
content = content.replace('style="-fx-background-color: #e2e8f0; -fx-background-radius: 12;"', 'styleClass="viewer-main-area"')
content = content.replace('style="-fx-background-color: #ffffff; -fx-background-radius: 20; -fx-border-color: #cbd5e1; -fx-border-radius: 20; -fx-text-fill: #1e293b; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 8 20 8 20; -fx-cursor: hand;"', 'styleClass="viewer-nav-btn"')
content = content.replace('style="-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #1e293b;"', 'styleClass="viewer-tracker-label"')

with codecs.open(path, 'w', 'utf-8') as f:
    f.write(content)
