﻿import codecs
import re

path = 'C:/Users/raffy/Desktop/MyPatenti Prova/src/main/java/controller/DashboardController.java'
with codecs.open(path, 'r', 'utf-8', errors='ignore') as f:
    content = f.read()

content = re.sub(r'menuProfilo\.setText\([^)]+\);', 'menuProfilo.setText("\U0001F464 Ciao, " + nomeUtenteLoggato);', content)
content = re.sub(r'lblBenvenuto\.setText\([^)]+\);', 'lblBenvenuto.setText("Bentornato, " + nomeUtenteLoggato + "! \U0001F44B");', content)

with codecs.open(path, 'w', 'utf-8') as f:
    f.write(content)

path2 = 'C:/Users/raffy/Desktop/MyPatenti Prova/src/main/resources/view/Dashboard.fxml'
with codecs.open(path2, 'r', 'utf-8', errors='ignore') as f:
    content2 = f.read()

content2 = re.sub(r'text="[^"]+ Ciao, Utente"', 'text="\U0001F464 Ciao, Utente"', content2)
content2 = re.sub(r'text="Bentornato, Cristian! [^"]+"', 'text="Bentornato, Cristian! \U0001F44B"', content2)

with codecs.open(path2, 'w', 'utf-8') as f:
    f.write(content2)
