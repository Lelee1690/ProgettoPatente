﻿import codecs
import re

path = 'C:/Users/raffy/Desktop/MyPatenti Prova/src/main/java/controller/VisualizzatoreController.java'
with codecs.open(path, 'r', 'utf-8', errors='ignore') as f:
    content = f.read()

content = content.replace('wrapper.setStyle("-fx-border-color: #3b82f6; -fx-border-width: 3; -fx-border-radius: 8; -fx-background-radius: 8; -fx-padding: 2; -fx-background-color: #eff6ff;");', 'wrapper.getStyleClass().setAll("thumb-wrapper-active");')
content = content.replace('wrapper.setStyle("-fx-border-color: #cbd5e1; -fx-border-width: 2; -fx-border-radius: 8; -fx-background-radius: 8; -fx-padding: 2; -fx-background-color: transparent;");', 'wrapper.getStyleClass().setAll("thumb-wrapper");')

with codecs.open(path, 'w', 'utf-8') as f:
    f.write(content)
