﻿import codecs
import re

path = 'C:/Users/raffy/Desktop/MyPatenti Prova/src/main/java/controller/DashboardController.java'
with codecs.open(path, 'r', 'utf-8', errors='ignore') as f:
    content = f.read()

content = re.sub(r'menuProfilo\.setText\([^)]+\);', 'menuProfilo.setText("\U0001F44B Ciao, " + nomeUtenteLoggato);', content)
content = re.sub(r'lblBenvenuto\.setText\([^)]+\);', 'lblBenvenuto.setText("Bentornato, " + nomeUtenteLoggato + "! \U0001F697");', content)

with codecs.open(path, 'w', 'utf-8') as f:
    f.write(content)
